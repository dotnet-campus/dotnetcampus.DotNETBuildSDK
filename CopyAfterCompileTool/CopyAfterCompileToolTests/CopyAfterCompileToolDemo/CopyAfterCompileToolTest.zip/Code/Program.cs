﻿using System;

namespace CopyAfterCompileToolTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("版本3");
        }
    }
}
